module.exports = {
	tags: [
		"events"
	],
	"layout": "layouts/event.njk",
};
