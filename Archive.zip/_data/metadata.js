module.exports = {
	title: "Diamond Homes Realty,",
	url: "https://discountrealty.online/",
	language: "en",
	description: "I am writing about my experiences as a naval navel-gazer.",
	author: {
		name: "Med Housni",
		email: "med.houssni@gmail.com",
		url: "#"
	}
}
